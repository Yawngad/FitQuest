package com.fitquest.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.DayOfWeek

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fitquest", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val bg = Color.rgb(16, 26, 20)
    private val panel = Color.rgb(27, 43, 32)
    private val mint = Color.rgb(198, 246, 213)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 207, 195)

    private data class DayPlan(val title: String, val subtitle: String, val items: List<String>)
    private fun plan(day: DayOfWeek = LocalDate.now().dayOfWeek): DayPlan = when(day) {
        DayOfWeek.MONDAY -> DayPlan("Strength A", "Build strength · 20–30 min", listOf("Squats · 2 × 10–12", "Push-ups · 2 × 6–10", "Glute bridges · 2 × 12–15", "Pull-up progression · 2 comfortable attempts", "Plank · 2 × 15–25 sec"))
        DayOfWeek.TUESDAY -> DayPlan("Easy Run", "Easy pace · 25–30 min", listOf("5 min warm-up walk", "Jog 1 min / walk 2 min · 6–7 rounds", "5 min cool-down walk"))
        DayOfWeek.WEDNESDAY -> DayPlan("Recovery", "Rest and reset", listOf("Optional easy walk · 10–15 min", "Mobility routine"))
        DayOfWeek.THURSDAY -> DayPlan("Strength B", "Build strength · 20–30 min", listOf("Reverse lunges · 2 × 8 per leg", "Push-ups · 2 × 6–8", "Hip hinges · 2 × 12", "Pull-up progression · 2 comfortable attempts", "Side plank · 2 × 15–20 sec per side"))
        DayOfWeek.FRIDAY -> DayPlan("Easy Run", "Easy pace · about 30 min", listOf("5 min warm-up walk", "Jog 2 min / walk 2 min · 5–6 rounds", "5 min cool-down walk"))
        DayOfWeek.SATURDAY -> DayPlan("Rest Day", "Take it easy", listOf("Rest", "Optional gentle stretching"))
        DayOfWeek.SUNDAY -> DayPlan("Optional Mobility", "Move gently · 15–20 min", listOf("Easy walk", "Mobility routine"))
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); renderToday() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply { text=value; textSize=size; setTextColor(color); if(bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(3), 0, dp(3)) }
    private fun button(value: String, action: () -> Unit): Button = Button(this).apply { text=value; setTextColor(white); setOnClickListener { action() } }
    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(22), dp(20), dp(24)) }
        val scroller = android.widget.ScrollView(this); scroller.addView(root); setContentView(scroller)
        root.addView(text("FITQUEST", 13f, mint, true)); root.addView(text(title, 28f, white, true)); root.addView(text("Small steps. Strong habits.", 14f, muted))
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0, dp(10), 0, dp(12)) }
        listOf("Today", "Week", "Mobility", "Progress").forEach { label -> nav.addView(button(label) { when(label) { "Today" -> renderToday(); "Week" -> renderWeek(); "Mobility" -> renderMobility(); else -> renderProgress() } }, LinearLayout.LayoutParams(0, dp(48), 1f)) }
        root.addView(nav)
    }
    private fun card() = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(16), dp(14), dp(16), dp(14)) }
    private fun todayKey() = LocalDate.now().toString()
    private fun streak(): Int { var n=0; var d=LocalDate.now(); if(!prefs.getBoolean("done_${d}", false)) d=d.minusDays(1); while(prefs.getBoolean("done_${d}", false)){ n++; d=d.minusDays(1) }; return n }
    private fun renderToday() {
        val p=plan(); base("Today's mission")
        root.addView(text(LocalDate.now().dayOfWeek.name + " · " + p.title.uppercase(), 20f, white, true))
        root.addView(text(p.subtitle, 15f, muted))
        val c=card(); c.addView(text("🔥  ${streak()} day streak", 17f, mint, true)); c.addView(text("Mark each exercise as you finish.", 13f, muted)); root.addView(c)
        val checkKey="checks_${todayKey()}_${p.title}"
        p.items.forEachIndexed { i, item ->
            val check=CheckBox(this).apply { text=item; setTextColor(white); buttonTintList=android.content.res.ColorStateList.valueOf(mint); isChecked=prefs.getBoolean("${checkKey}_$i",false); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("${checkKey}_$i",checked).apply() } }
            root.addView(check)
        }
        root.addView(button(if(prefs.getBoolean("done_${todayKey()}",false)) "Workout completed ✓" else "Complete today's session") {
            prefs.edit().putBoolean("done_${todayKey()}",true).apply(); updateWidget(); renderToday()
        })
        root.addView(text("Remember: keep the pace comfortable. Rest if something hurts.", 13f, muted))
    }
    private fun renderWeek() { base("Your week"); listOf(DayOfWeek.MONDAY,DayOfWeek.TUESDAY,DayOfWeek.WEDNESDAY,DayOfWeek.THURSDAY,DayOfWeek.FRIDAY,DayOfWeek.SATURDAY,DayOfWeek.SUNDAY).forEach { d -> val p=plan(d); val c=card(); c.addView(text("${d.name} · ${p.title}",16f,white,true)); c.addView(text(p.subtitle,13f,muted)); root.addView(c); spacer() } }
    private fun renderMobility() { base("Mobility"); root.addView(text("Gentle 15–20 minute routine",16f,mint,true)); val items=listOf("Lying hamstring stretch · 30 sec × 2 each leg","Figure-4 glute stretch · 30 sec × 2 each side","Half-kneeling hip flexor stretch · 30 sec × 2 each side","Butterfly stretch · 30–45 sec × 2","90/90 hip stretch · 30 sec × 2 each side","Child’s pose · 30–45 sec × 2","Knee-to-wall ankle mobility · 10 reps × 2 each leg","Standing knee raises · 2 × 10 each leg","Front-back leg swings · 2 × 10 each leg","Rock-backs · 2 × 10","Dead bugs · 2 × 6 each side"); items.forEach { root.addView(text("• $it",15f,white)); spacer() }; root.addView(text("Keep every movement comfortable. Don’t force range or stretch into pain.",13f,muted)) }
    private fun renderProgress() { base("Progress"); root.addView(text("🔥 ${streak()} day streak",22f,mint,true)); val count=prefs.all.keys.count { it.startsWith("done_") && prefs.getBoolean(it,false) }; root.addView(text("Completed sessions: $count",16f,white)); root.addView(text("Focus on showing up, learning the movements and recovering well—not on changing your body measurements.",14f,muted)) }
    private fun spacer(){ val v=View(this); root.addView(v,LinearLayout.LayoutParams(1,dp(10))) }
    private fun updateWidget(){ val mgr=AppWidgetManager.getInstance(this); val ids=mgr.getAppWidgetIds(ComponentName(this,FitQuestWidgetProvider::class.java)); FitQuestWidgetProvider.updateAll(this,mgr,ids) }
}
