package com.fitquest.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.DayOfWeek
import java.time.LocalDate

class FitQuestWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = updateAll(context,manager,ids)
    override fun onReceive(context: Context, intent: Intent) { super.onReceive(context,intent); if(intent.action=="com.fitquest.app.UPDATE_WIDGET") { val mgr=AppWidgetManager.getInstance(context); updateAll(context,mgr,mgr.getAppWidgetIds(android.content.ComponentName(context,FitQuestWidgetProvider::class.java))) } }
    companion object {
        fun updateAll(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs=context.getSharedPreferences("fitquest",Context.MODE_PRIVATE)
            val day=LocalDate.now().dayOfWeek
            val title=when(day){ DayOfWeek.MONDAY->"Strength A"; DayOfWeek.TUESDAY->"Easy Run"; DayOfWeek.WEDNESDAY->"Recovery"; DayOfWeek.THURSDAY->"Strength B"; DayOfWeek.FRIDAY->"Easy Run"; DayOfWeek.SATURDAY->"Rest Day"; else->"Optional Mobility" }
            var streak=0; var d=LocalDate.now(); if(!prefs.getBoolean("done_$d",false)) d=d.minusDays(1); while(prefs.getBoolean("done_$d",false)){ streak++; d=d.minusDays(1) }
            val summary=when(day){DayOfWeek.MONDAY->"Squats · push-ups · core"; DayOfWeek.TUESDAY->"Easy jog / walk intervals"; DayOfWeek.WEDNESDAY->"Rest or light mobility"; DayOfWeek.THURSDAY->"Lunges · push-ups · core"; DayOfWeek.FRIDAY->"Easy jog / walk intervals"; DayOfWeek.SATURDAY->"Recovery day"; else->"Walk and gentle mobility"}
            ids.forEach { id -> val views=RemoteViews(context.packageName,R.layout.fitquest_widget); views.setTextViewText(R.id.widget_title,title); views.setTextViewText(R.id.widget_summary,summary); views.setTextViewText(R.id.widget_streak,"🔥 $streak day streak")
                val intent=Intent(context,MainActivity::class.java); val pending=PendingIntent.getActivity(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); views.setOnClickPendingIntent(R.id.widget_title,pending); views.setOnClickPendingIntent(R.id.widget_summary,pending); views.setOnClickPendingIntent(R.id.widget_streak,pending); manager.updateAppWidget(id,views) }
        }
    }
}
